package com.example.myassignment;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {

    EditText uname, passcode;
    TextView fdBack;
    String username, password, feedBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        uname = findViewById(R.id.edtUserName);
        passcode = findViewById(R.id.edtPassword);
        fdBack = findViewById(R.id.loginFeedBack);
    }

    public void loginClicked(View v){
        username = uname.getText().toString();
        password = passcode.getText().toString();

        if (username.contentEquals("admin") && password.contentEquals("123")){
            feedBack = "Login Successful";
            fdBack.setTextColor(Color.BLUE);
        }else{
            feedBack = "Invalid";
            fdBack.setTextColor(Color.RED);
        }

        fdBack.setText(feedBack);
    }

    public void registerClicked(View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
